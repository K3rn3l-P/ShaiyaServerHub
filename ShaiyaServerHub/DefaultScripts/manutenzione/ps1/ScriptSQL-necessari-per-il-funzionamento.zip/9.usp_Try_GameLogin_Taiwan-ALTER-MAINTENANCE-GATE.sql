/* ============================================================================
   9.usp_Try_GameLogin_Taiwan-ALTER-MAINTENANCE-GATE.sql

   Aggiunge il gate "Modalita Manutenzione" a usp_Try_GameLogin_Taiwan (login
   server, chiamato AD OGNI LOGIN). Corpo IDENTICO al file "2.usp_Try_Game
   Login_Taiwan.sql" (baseline gia' presente in questa cartella) + UN blocco
   nuovo inserito subito dopo il controllo AdminUserWhitelist esistente,
   prima della SELECT finale di @Status.

   PREREQUISITO: eseguire PRIMA "8.MaintenanceMode(ModalitaManutenzione).sql"
   (crea PS_UserData.dbo.MaintenanceMode). Se la tabella non esiste, il gate
   sotto fallirebbe con "Invalid object name".

   COSA FA IL GATE: se PS_UserData.dbo.MaintenanceMode.Enabled=1 e l'account
   NON e' GM/admin (@Status non in 16/32/48/64/80 — STESSA definizione del
   controllo AdminUserWhitelist qui sopra), il login viene negato (@Status=-1).
   Gli admin whitelisted continuano a entrare come sempre. Il flag e' riletto
   dalla tabella AD OGNI login: attivare/disattivare la manutenzione da
   ShaiyaServerHub ha effetto IMMEDIATO, senza restart di ps_login.

   ATTENZIONE — proc CRITICA:
   - Fai un backup/verifica della definizione corrente PRIMA di eseguire
     (SELECT OBJECT_DEFINITION(OBJECT_ID('dbo.usp_Try_GameLogin_Taiwan'))).
   - Testa PRIMA su un server/DB di copia, MAI direttamente in produzione.
   - Se in futuro "2.usp_Try_GameLogin_Taiwan.sql" viene rieseguito (es. dopo
     una reinstallazione pulita), il gate manutenzione va riapplicato
     rieseguendo QUESTO file dopo.
   ============================================================================ */
USE [PS_UserData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO

-- @ArgonResult = NULL  -> legacy path: sp_LoginSuccessCheck does rate limit + pw check + logging
-- @ArgonResult = 0/1   -> PBKDF2 path: C++ already verified password, SP does rate limit + logging directly

ALTER PROCEDURE [dbo].[usp_Try_GameLogin_Taiwan]
        @UserID             varchar(18),
        @InPassword         varchar(32),
        @SessionID          bigint,
        @UserIP             varchar(15),
        @UserUID            int       = 0,
        @LoginType          smallint  = 1,
        @LoginTime          datetime  = NULL,
        @ArgonResult        bit       = NULL    -- NEW: NULL = legacy, 0/1 = PBKDF2 result from C++
AS
BEGIN
        SET NOCOUNT ON;

        DECLARE
                @Leave          tinyint,
                @Status         smallint,
                @CompanyIP      varchar(15),
                @TempIP         varchar(15),
                @Check          int;

        SET @Status    = -1;
        SET @LoginTime = GETDATE();
        SET @CompanyIP = '61.107.81';
        SET @UserIP    = LTRIM(RTRIM(@UserIP));
        SET @Check     = 0;

        SELECT @UserUID = UserUID, @Status = Status, @Leave = Leave
        FROM   Users_Master
        WHERE  UserID = @UserID;

        IF (@UserUID = 0 OR @Leave = 1)
        BEGIN
                SET @Status = -3;
        END
        ELSE
        BEGIN
                IF @ArgonResult IS NULL
                BEGIN
                        -- Legacy path: sp_LoginSuccessCheck handles rate limit + pw check + logging
                        EXEC dbo.sp_LoginSuccessCheck @UserID, @InPassword, @UserIP, @Check OUTPUT;
                        IF (@@ERROR = 0)
                        BEGIN
                                IF (@Check <> 1)
                                        SET @Status = -1;
                        END
                        ELSE
                        BEGIN
                                SET @Status = -1;
                        END
                END
                ELSE
                BEGIN
                        -- PBKDF2 path: rate limit + logging directly, pw already verified by C++
                        DECLARE @IsAllowed BIT;
                        EXEC dbo.CheckLoginRateLimit @UserID, @UserIP, @IsAllowed OUTPUT;

                        IF @IsAllowed = 0
                        BEGIN
                                INSERT INTO dbo.LoginAttempts (UserID, IPAddress, Success, FailureReason)
                                VALUES (@UserID, @UserIP, 0, 'Rate limit exceeded');
                                SET @Status = -99;
                        END
                        ELSE IF @ArgonResult = 0
                        BEGIN
                                INSERT INTO dbo.LoginAttempts (UserID, IPAddress, Success, FailureReason)
                                VALUES (@UserID, @UserIP, 0, 'Invalid credentials');
                                SET @Status = -1;
                        END
                        ELSE
                        BEGIN
                                INSERT INTO dbo.LoginAttempts (UserID, IPAddress, Success, FailureReason)
                                VALUES (@UserID, @UserIP, 1, NULL);
                                -- @Status stays as DB value (0=active, 16/32/48/64/80=GM tiers)
                        END
                END
        END

        IF (@Status IN (16, 32, 48, 64, 80))
        BEGIN
                IF NOT EXISTS (
                        SELECT 1 FROM dbo.AdminUserWhitelist
                        WHERE UserUID = @UserUID AND UserID = @UserID
                )
                BEGIN
                        SET @Status = -999;
                END
        END

        -- ==== MAINTENANCE GATE (nuovo) ============================================
        -- Se attiva, blocca i player normali (non-GM). Stessa definizione admin del
        -- blocco AdminUserWhitelist sopra: @Status IN (16,32,48,64,80).
        IF (@Status NOT IN (16, 32, 48, 64, 80))
        BEGIN
                IF EXISTS (SELECT 1 FROM dbo.MaintenanceMode WHERE Enabled = 1)
                BEGIN
                        SET @Status = -1;
                END
        END
        -- ==== FINE MAINTENANCE GATE ================================================

        SELECT @Status AS Status, @UserUID AS UserUID;

        IF (@Status IN (0, 16, 32, 48, 64, 80))
        BEGIN
                EXEC usp_Insert_LoginLog_E
                        @SessionID  = @SessionID,
                        @UserUID    = @UserUID,
                        @UserIP     = @UserIP,
                        @LogType    = 0,
                        @LogTime    = @LoginTime,
                        @LoginType  = @LoginType;
        END

        SET NOCOUNT OFF;
END
GO

-- Verifica post-deploy
IF OBJECT_ID('dbo.usp_Try_GameLogin_Taiwan') IS NOT NULL
    PRINT 'OK: usp_Try_GameLogin_Taiwan aggiornata con gate manutenzione';
ELSE
    PRINT 'ERRORE: procedura non trovata dopo ALTER';
GO
