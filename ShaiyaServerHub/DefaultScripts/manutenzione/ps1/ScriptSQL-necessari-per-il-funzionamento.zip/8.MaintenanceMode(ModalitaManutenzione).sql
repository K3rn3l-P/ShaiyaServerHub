/* ============================================================================
   8.MaintenanceMode(ModalitaManutenzione).sql
   Tabella toggle "Modalita Manutenzione" per il pulsante Manutenzione in
   ShaiyaServerHub (Dashboard). Una singola riga bit: Enabled=1 -> il gate in
   9.usp_Try_GameLogin_Taiwan-ALTER-MAINTENANCE-GATE.sql nega il login ai
   player normali (Status non in 16/32/48/64/80) e lascia passare gli admin.

   ESEGUIRE QUESTO FILE PRIMA del file 9. Idempotente: rieseguibile senza
   effetti collaterali (non duplica la riga, non fallisce se gia' presente).
   ============================================================================ */
USE [PS_UserData]
GO

IF OBJECT_ID('dbo.MaintenanceMode') IS NULL
BEGIN
    CREATE TABLE dbo.MaintenanceMode
    (
        Enabled   bit           NOT NULL,
        ChangedAt datetime      NULL,
        ChangedBy nvarchar(128) NULL
    );
    INSERT INTO dbo.MaintenanceMode (Enabled, ChangedAt, ChangedBy)
    VALUES (0, GETDATE(), SUSER_SNAME());
END
GO

-- Garantisce sempre esattamente una riga (difesa extra se la tabella esisteva vuota).
IF NOT EXISTS (SELECT 1 FROM dbo.MaintenanceMode)
    INSERT INTO dbo.MaintenanceMode (Enabled, ChangedAt, ChangedBy)
    VALUES (0, GETDATE(), SUSER_SNAME());
GO

-- Verifica
SELECT * FROM dbo.MaintenanceMode;
GO
